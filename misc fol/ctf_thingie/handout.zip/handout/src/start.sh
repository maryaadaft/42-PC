#! /bin/sh

cd /ctf
timeout 30s ./all