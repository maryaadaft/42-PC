# push_swap
## Sort a stack using a helper a stack but with restrictions.
### You are only allowed to use a set of moves. 
1- swap the top 2 items (sa and sb)<br />
2- rotate a stack or reverse rotate a stack, put the top item at the bottom or other way around (ra and rb or rra and rrb)<br />
3- You could do 1 or 2 togather at the same time, for example you could rotate a and b with one move (rr or rrr)<br />

This project might be hard incase you are bad in data structures and algorithms.
