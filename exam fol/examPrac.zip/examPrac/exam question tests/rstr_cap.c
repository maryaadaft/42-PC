#include <unistd.h>
#include <stdio.h>

int	main(int argc, char **argv)
{
	int i;
	int w;
	int l;
	i = 0;
	w = 1;
	if (argc > 1)
	{
		while (w < argc)
		{

		}
	}
}